# COMP 3612, Fall 2021
### Assessment for Lab #6 on Chapter 13

I will mark Chapter 13, Project 3 in textbook, pages 708-710. I have also provided a PDF of those pages. The last set of exercises in Lab13 provide step-by-step exercises for creating a simple chat client, which you are expanding here.

I have provided the starting files here.


  
