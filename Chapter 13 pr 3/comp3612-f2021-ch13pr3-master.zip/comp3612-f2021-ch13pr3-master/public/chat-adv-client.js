document.addEventListener("DOMContentLoaded", function () {



  // get user name and then tell the server
  let username = prompt('What\'s your username?');  



  /* This user is sending a new chat message */
  document.querySelector("#chatForm").addEventListener('submit', e => {
    e.preventDefault();
    const entry = document.querySelector("#entry");

	
  });

  /* User has clicked the leave button */
  document.querySelector("#leave").addEventListener('click', e => {
    e.preventDefault();

	
  });  



  

});

